package com.example.cities;

    import android.content.DialogInterface;

    public interface DialogCloseListener {
        public void handleDialogClose(DialogInterface dialog);
    }


