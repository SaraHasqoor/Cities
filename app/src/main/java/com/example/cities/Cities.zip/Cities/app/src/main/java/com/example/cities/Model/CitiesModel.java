package com.example.cities.Model;

public class CitiesModel {
    private int id, status;
    private String place;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getplace() {
        return place;
    }

    public void setPlace(String place) {
        this.place = place;
    }
}


